#!/sbin/sh



# Example:

# ui_print "Applying update..."
#
# package_extract_file newbinary $INSTALLDIR/newbinary
#
# mv $INSTALLDIR/newbinary /system/bin/newbinary
#
# set_metadata /system/bin/newbinary uid root gid shell mode 755
#
# 
# ui_print "Update successfully installed!"
ui_print "";
ui_print "";
ui_print "#########################################";
ui_print "#                                       #";
ui_print "#            Stock recovery             #"; 
ui_print "#                                       #";
ui_print "#                                       #";
ui_print "#            by Abdelhay Ali            #";
ui_print "#                                       #";
ui_print "#                                       #";
ui_print "#               V2.0 beta               #";
ui_print "#                                       #";
ui_print "#########################################";
ui_print "";
ui_print "";




#abort if any error occurred 
#set -e
ui_print "";
mv $INSTALLDIR/res/ /
mv $INSTALLDIR/sbin/ /
ui_print "This is  a beta version";
sleep 1
ui_print "recovery will start now";
sleep 1
ui_print "Touch on the middle of the screen  ";
ui_print "Then use volume up/down and power button for navigation ";
stock-recovery
sleep 3
sleep infinity

      ui_print "Update successfully installed!"
exit 0;